<?php include ('header.php')?>

      <!-- Start Page Header -->
 <div class="page-header banner bg9 bnr">
        <div class="container">
         <div class="row">
               <div class="heading">
                <div class="section-title"><span class="txclr">Travel   </span><span> Technology </span></div>
            </div>
          </div>
        </div>
      </div>  	  
      <!-- End Page Header -->
      <!-- Start About Section  -->
      <section class="about section">
        <div class="container">
          <div class="row">
            <div class="col-md-6 about-us-text">
              <!-- Classic Heading -->
              <p>
               Travel Technology is an evolving trend which is slowly making travel industry feel that finally a solution is there that can give them access to a real time inventory. We at Sia Smtech Solutions pay due attention towards the latest and evolving travel technology standards in the market. Few years from now there was little scope of an online booking system. Packages were sold as an offline mode and ticketing was done directly from the Flights counters available at the airports. With time, technology evolved and all the Flights were brought under one single umbrella called GDS system. Local Carriers were left out from this system as they wanted to operate independently in there respective nations. Through this GDS connectivity travel agents could get an access to all the International and Domestic Flights across the globe. Similar trends were followed with Hotels when scores of wholesalers sprang up providing there array of inventory. Followed by Cars, Transfers and Sight seeing. All these offers are bundled into an API/XML system and we, Travel Technology companies so the integration process.
              </p>
              <p>
               This Travel Technology is a boon to the travel agents who can now process there entire business online and in a hassle Free environment.
              </p>
            </div>
            <div class="col-md-6">
              <div class="featured-thumb">
                <img src="assets/img/technology/img2.png" alt="">
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- End About Section  -->
	 
         <?php include ('footer.php')?>
