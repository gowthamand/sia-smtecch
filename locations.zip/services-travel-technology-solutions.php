     <?php include ('header.php')?>

      <!-- Start Page Header -->
 <div class="page-header banner bg10 bnr">
      <div class="container">
       <div class="row">
<div class="heading">
                <div class="section-title"><span class="txclr">Travel    </span><span> Technology Solutions </span></div>
            </div>
       </div>
     </div>
   </div> 	  
      <!-- End Page Header -->
      <!-- Start About Section  -->
      <section class="about section">
        <div class="container">
          <div class="row">
            <div class="col-md-12 about-us-text">
              <!-- Classic Heading -->
              <p>
               Sia Smtech Solutions have a flurry of products for your Travel Technology Solutions and Travel Business. Built specifically for the travel operators across the globe, we have come up with few really innovative travel technology solutions for our clients in Africa zone. We have been voted as best travel portal development company in Nigeria by connect, a Leading directory based out of Lagos. As a leading GDS integration company for Africa, we provide a plethora of solutions meant for Best Travel Technology Solutions, ravel Portal Development Company, Best Travel Technology, Travel Booking Engine Development, Travel Portal Software Solutions, Online Travel Booking Software, Best B2B and B2C Travel Portal Development and Travel Booking Engine Software. Any GDS/XML/API integration services are done at our offshore canter and we give you a seamless and sustainable product out of the development phase. Apart from a regular CRS system for Hotel Booking Engine and Tour Packages system we also provide you in-built software for safari packages. This software enables you to upload your own safari packages and put your mark-ups from the admin area. Africa’s travel portal development would be incomplete without a safari section, and this is a gift for our clients based in Africa. We are the Best Travel Technology Solutions Software Company and builds Travel Portals for business Easton Middle East, Africa, Asia,  Oman, Jordan, Bangladesh, East and South Asia, India, Nigeria, Kenya, Ethiopia, Tanzania, Hongkong Malaysia, Japan, Tokyo, Maldives, France, Ghana & Namibia. In Nigeria, hotel wholesalers are chosen specifically as per the client’s target market and this forms as one of our major tool. Owing to our associations with these suppliers, the API/XML is obtained at a much faster pace.
              </p>
              <p>
               Our major and the most prolific offer to our client come in terms of the religious packages. Owing to our association with major suppliers for Haj & Umrah, we offer our clients a fully-fledged Haj & Umrah packages tours laced with all the amenities. This package is provided FREE with the Travel Technology Solutions, ravel Portal Development Company, Best Travel Technology, Travel Booking Engine Development, Travel Portal Software Solutions, Online Travel Booking Software, Best B2B and B2C Travel Portal Development and Travel Booking Engine Software. Africa’s travel portal development industry has never witnessed such an offer and we feel pleased to serve our client with this offer. As a leading Africa GDS integration company, Sia Smtech Solutions feels proud to be associated with leading payment gateway companies from Nigeria and Kenya, whose services we have used in our GDS/API/XML integration. Best haj & Umrah packages are right now available on demand from our clients. We have to start working on their travel portal development and we provide you safari packages with best Haj & Umrah packages.
              </p>			 
            </div>
           <!-----<div class="col-md-3">
              <div class="featured-thumb">
			  <div class="travel-tech" >
<div class="right-red-button"><a href="services.html"> OUR OTHER SERVICES</a></div>
<div class="white-bg">
<p><strong><a href="services-travel-portal-development.html">Travel Portal Development</a></strong></p>
<p><strong><a href="services-airline-reservation-system.html">Airline Reservation System</a></strong></p>
<p><strong><a href="services-hotel-booking-system.html">Hotel Booking System</a></strong></p>
<p><strong><a href="services-gds-xml-api-integration.html">GDS/XML/API Integration</a></strong></p>
<p><strong><a href="services-e-commerce-portal.html">E-commerce Portal</a></strong></p>
<p><strong><a href="services-job-board-development.html">Job Board Development</a></strong></p>
<p><strong><a href="services-3rd-party-flight-integrations.html">3rd Party Flight Integrations</a></strong></p>
<p><strong><a href="http://siasmtech.com/services-packages-and-tours">Packages and Tours</a></strong></p>
</div>
</div>
			  
               
              </div>
            </div>------>
          </div>
        </div>
      </section>
      <!-- End About Section  -->
	 
         <?php include ('footer.php')?>