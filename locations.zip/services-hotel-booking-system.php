     <?php include ('header.php')?>

      <!-- Start Page Header -->
  <div class="page-header banner bg13 bnr">
      <div class="container">
       <div class="row">
<div class="heading">
                <div class="section-title"><span class="txclr">Hotel    </span><span> Booking System </span></div>
            </div>
       </div>
     </div>
   </div>   
      <!-- End Page Header -->
      <!-- Start About Section  -->
      <section class="about section">
        <div class="container">
          <div class="row">
            <div class="col-md-12 about-us-text">
              <!-- Classic Heading -->
              <p>
               Sia Smtech Solutions had been dedicated towards the cause of travel industry for some time now. As a leading online Android app for  Hotel Reservation and Hotel Booking Technology Systems for Agencies, we take care of complete development, design, procuring the relevant GDS/XML/API for our client so that there travel booking engine software is at par with any of their competitors.
              </p>
              <p>
               Normally clients are not aware of the best wholesaler to suit their target market. Sia Smtech Solutions not only hooks them with the most affordable supplier but also negotiates on the guarantee money on their behalf. As a south Africa and Oman Jordan travel portal development company, we keep a hawk’s eye on the emerging sector on travel arena and do our best to come with an innovative travel booking engine software every time.
              </p>
			  <p>Every country has its own specific and charismatic appeals. For example, Africa has Safari, Middle East has Haj & Umrah Packages, USA has some exotic locations, Far-east has some exquisite honeymoon destinations, and Europe has its own local flairs. We try to build a travel agencies booking engine software that encompasses all the features scattered along the globe. For this we have handpicked the wholesalers and would recommend them to our clients. Sia Smtech Solutions is not involved in any monetary gains from these suppliers. Best Flight and Hotels Technology Company, GDS/XML/API Integration Services across the globe (India, Africa, Kenya, Nigeria, Tanzania, South Africa, Dubai, Malaysia, Singapore, Hong Kong and France, Oman and Jordan etc) As a leading Africa travel portal development company, we understand our responsibility.</p>
			  <p>We would love to hear from you and your ideas. Let us have this opportunity to turn your dreams into reality.</p>
            </div>
           <!---<div class="col-md-3">
              <div class="featured-thumb">
			  <div class="hotel-booking-system" >
<div class="right-red-button"><a href="services.html"> OUR OTHER SERVICES</a></div>
<div class="white-bg">
<p><strong><a href="services-travel-portal-development.html">Travel Portal Development</a></strong></p>
<p><strong><a href="services-airline-reservation-system.html">Airline Reservation System</a></strong></p>
<p><strong><a href="services-gds-xml-api-integration.html">GDS/XML/API Integration</a></strong></p>
<p><strong><a href="services-e-commerce-portal.html">E-commerce Portal</a></strong></p>
<p><strong><a href="services-travel-technology-solutions.html">Travel Technology Solutions</a></strong></p>
<p><strong><a href="services-job-board-development.html">Job Board Development</a></strong></p>
<p><strong><a href="services-3rd-party-flight-integrations.html">3rd Party Flight Integrations</a></strong></p>
<p><strong><a href="http://siasmtech.com/services-packages-and-tours">Packages and Tours</a></strong></p>
</div>
</div>
			  
               
              </div>
            </div>------->
          </div>
        </div>
      </section>
      <!-- End About Section  -->
	 
          <?php include ('footer.php')?>