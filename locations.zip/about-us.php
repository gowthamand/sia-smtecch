<?php include ('header.php')?>

      <!-- Start Page Header -->
	   <div class="page-header banner bg8 bnr">
        <div class="container">
         <div class="row">
               <div class="heading">
                <div class="section-title"><span class="txclr">About  </span><span> Team </span></div>
            </div>
          </div>
        </div>
      </div>    
      <!-- End Page Header -->
      <!-- Start About Section  -->
      <section class="about section">
        <div class="container">
          <div class="row">
            <div class="col-md-12 about-us-text">
              <!-- Classic Heading -->
              <p>
               Sia Smtech Solutions is not just the best travel portal development company of Africa, as our existence must suggest, but we cater to the whole gamut of Travel agents and Tour Operators across the world. We provide Flights, Hotels, Transfers, Bus, Cars and Yachts API/XML services along with the facility to develop an offline system for all the bookings. This is a Central Reservation System which would work as an Extranet for all the modules. The whole Travel portal comes with inbuilt payment gateway and packages creation section. Admin can create all the packages pertaining to his/her facility and availability of inventory. This is the whole portal could be termed as the Best Travel portal Development with services and packages. We at our India ODC, cater to complete development and design process. With a backup of more than 50+ chosen developers, we provide a round the clock facility for our clients to check, test and modify their existing and on-going jobs. With a sprawling campus and meeting rooms, we make sure that any possible discussion pertaining to the betterment of a Travel portal, happens amidst all concerned people. The offices located overseas are for our Sales personnel. We make sure that there is a positive word-of-mouth marketing towards our services and products. Possible clients could very well connect with us using our direct contact numbers available on the Website.
              </p>
              <p>
               This requires a lot of courage and dedication to emerge as the best travel portal development company service & packages as the market to which we are catering is very niche and focused. There is only one mode of a good publicity, which comes from the client. A happy and satisfied client could refer to many others. Clients can find our presence dominantly in the African market and then sprawling towards Far East and Middle East. We are open to any sort of Technical challenges coming from the Travel Technology Domain.
              </p>
					
            </div>
            
          </div>
        </div>
      </section>
      <!-- End About Section  -->
	  
	  
     <?php include ('footer.php')?>