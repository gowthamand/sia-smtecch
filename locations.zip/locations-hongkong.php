<?php include ('header.php')?>

      <!-- Start Page Header -->
	   <!-- Start Page Header -->
	  <div class="page-header banner" style="background: url(assets/img/locations/banner.png); height:500px;">
       <!-- <div class="container">
         <div class="row">
            <div class="col-md-12">
              <h2 class="technology-title entry-title"><span>locations</span> </h2>              
            </div>
          </div> 
        </div> -->
      </div> 
     
      <!-- End Page Header -->        
      
      <!-- Start Content Section -->
      <section id="content">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <!-- Start Big title -->
              <h1 class="big-title">
                Travel Portal Development Company
              </h1>
              <!-- Accordion -->
              <div class="panel-group" id="accordion">
                
				<!-- Start Accordion 9 -->
                <div class="panel panel-default">
                  <!-- Toggle Heading -->
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapse-9" class="collapsed">
                      Hongkong  
                      </a>
                    </h4>
                  </div>
                  <!-- Toggle Content -->
                  <div id="collapse-9" class="panel-collapse collapse">
                    <div class="panel-body">
                      <p>The only motive of Sia Smtech Solutions was to become the best Travel Portal Development Company in Hongkong. Our aim was not just to provide the Travel Portal development, Travel Technology Solution, Travel Booking Engine Development, Travel Booking Software, Best B2B and B2C Travel Portal Development, Job Board Development, Hotel Reservation System, GDS/XML/API Integration, 3rd Party Flight Integration, E Commerce Portal Development Services, Airline Reservation Software design to the market but also to educate our clients, to get the best possible solutions in the market. There are numerous suppliers in the market today who would lure you by their inventory.</p>
					  <p>Without comparing the inventory, it’s normally not advisable to go for their API solutions. Before starting any GDS/XML/API integration solution for our client, we advise them by supplying them with the best wholesalers of their region with a comparative graph sheet. Client could visually check out the net rates available and then could make an idea of their mark ups, and eventually there profit.</p>
					  <p>Our travel booking engine software solutions combine the local GDS/XML/API integration solution with several packages which the client could make on their own by using the inventory of various wholesalers. These packages are custom built via the admin section of the portal and we assist the client various safari packages, Haj & Umrah packages, Honeymoon destinations and other related packages are built by the admin.</p>
					  <p>As the best hongkong travel technology company, we have had real time experience in training and teaching our clients to choose wisely the wholesalers and getting the best deals out of their investment. Best travel agencies software providers and travel portal development in hongkong have to be “the best” in all spheres.</p>
                    </div>
                  </div>
                </div>
                <!-- End Accordion 9 -->
              </div>
              <!-- End Accordion -->             
            
            </div>
          </div>
        </div>
      </section>
      <!-- End Content Section  -->
    
          <?php include ('footer.php')?>
