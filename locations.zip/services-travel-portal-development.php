     <?php include ('header.php')?>

      <!-- Start Page Header -->
	 <div class="page-header banner bg11 bnr">
      <div class="container">
       <div class="row">
<div class="heading">
                <div class="section-title"><span class="txclr">travel portal </span><span> development </span></div>
            </div>
       </div>
     </div>
   </div>   
      <!-- End Page Header -->
      <!-- Start About Section  -->
      <section class="about section">
        <div class="container">
          <div class="row">
            <div class="col-md-12 about-us-text">
              <!-- Classic Heading -->
              <p>
               Sia Smtech Solutions was incorporated keeping in mind the sole aim to promote Travel Portal Development Company, Best Travel Technology, Travel Booking Engine Development, Travel Portal Software Solutions, Best Android App for Travel Portals,Get Cheapest Android app for Travel Portals,Android app for Flight booking and Hotel Reservation Services, Online Travel Booking Software, Best B2B and B2C Travel Portal Development and the GDS/XML/API integration services in the comparatively lesser technology oriented African nations like Nigeria, Kenya, Ethiopia, Tanzania, Ghana and Namibia. You can avail Nigeria best hotel booking system development through our State-of-Art booking engine development process. Any travel booking software for business requires a professional approach and we are one of the pioneers of professional travel portal development company in Nigeria and neighboring nations. It’s not an easy task to emerge as one of the top class GDS/XML/API integration services providers in Africa. But owing to our deep rooted contacts with several suppliers and wholesalers, today we are the undisputed leaders in Africa travel technology solutions.
              </p>
              <p>
               Our major advantage is that we are available 24×7 at your services, which is a mandatory art for any travel booking Software Company for business. You can reach us, Ping us, Call us at any time you feel comfortable. It was a daunting task to emerge as a company who undertakes Nigeria’s best hotel booking system development as there was an apathy of knowledge among the travel agents. Our first task was to let them know about the technology. Educate them about GDS/XML/API integration services and our task was half done. Remaining half was supported by our clients who were keen to know about Africa travel technology solutions.
              </p>
			  <p>We are a group of enthusiasts who have studied deep about the Travel Booking Engine Development, Travel Portal Software Solutions, Online Travel Booking Software, Best B2B and B2C Travel Portal Development for business logic and our every development is aimed to maximize the ROI of our client. Most companies deliver the project and shrug off, we start after delivery!!! We make sure that your inventory is sold across the globe and you get your earnings back as soon as possible. We are the Best Travel Portal Development Software Company and builds portals for business, hotel booking system in Easton Middle East, Africa, Asia,  Oman, Jordan, Bangladesh, East and South Asia, Nigeria, Kenya, Ethiopia, Tanzania, India, Hong Kong, Malaysia, Japan, Tokyo, Maldives, Ghana & Namibia. There is no second thought as to why we are a professional travel portal company from Nigeria, as said and recommended by our clients. For us our clients are our repeated source of business.We respect them and their INVESTMENT.</p>
            </div>
            <!----<div class="col-md-3">
              <div class="featured-thumb">			  
			  <div class="avia_textblock">
				<div class="right-red-button"><a href="services.html"> OUR OTHER SERVICES</a></div>
					<div class="white-bg">
						<p><strong><a href="services-airline-reservation-system.html">Airline Reservation System</a></strong></p>
						<p><strong><a href="services-hotel-booking-system.html">Hotel Booking System</a></strong></p>
						<p><strong><a href="services-gds-xml-api-integration.html">GDS/XML/API Integration</a></strong></p>
						<p><strong><a href="services-e-commerce-portal.html">E-commerce Portal</a></strong></p>
						<p><strong><a href="services-travel-technology-solutions.html">Travel Technology Solutions</a></strong></p>
						<p><strong><a href="services-job-board-development.html">Job Board Development</a></strong></p>
						<p><strong><a href="services-3rd-party-flight-integrations.html">3rd Party Flight Integrations</a></strong></p>
						<p><strong><a href="http://siasmtech.com/services-packages-and-tours">Packages and Tours</a></strong></p>
					</div>
				</div>
              </div>
            </div>---->
              <div style="clear:both;"></div>
                <!----<div class="col-md-12">
                  <div class="col-md-3 pad_left0">
                      
                      <div class="item">
                          <img class="img_tra" src="assets/img/travel_portal/travel-portal1.png">

                          <div class="item-overlay top"></div>
                        </div>
                  </div>
                  <div class="col-md-3 pad_left0">
                      <div class="item">
                          <img class="img_tra" src="assets/img/travel_portal/4.jpg">

                          <div class="item-overlay top"></div>
                        </div>
                      
                  </div>
                  <div class="col-md-3 pad_left0">
                      <div class="item">
                          <img class="img_tra" src="assets/img/travel_portal/3.jpg">

                          <div class="item-overlay top"></div>
                        </div>
                      
                  </div>
                  <div class="col-md-3 pad_left0">
                      <div class="item">
                          <img class="img_tra" src="assets/img/travel_portal/4.jpg">

                          <div class="item-overlay top"></div>
                        </div>
                      
                  </div>
                </div>--->
          </div>
        </div>
      </section>
      <!-- End About Section  -->
	 
     
           <?php include ('footer.php')?>