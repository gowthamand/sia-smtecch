<?php include ('header.php')?>

      <!-- Start Page Header -->
	   <!-- Start Page Header -->
	  

       <div class="page-header banner bg1 bnr">
      <div class="container">
       <div class="row">
<div class="heading">
                <div class="section-title"><span class="txclr">BENEFITS   </span><span> AND REWARDS    </span></div>
            </div>
       </div>
     </div>
   </div> 
     
      <!-- End Page Header -->        
      
      <!-- Start Content Section -->
      <section id="content">
        <div class="container">
          <div class="row">

            
            <div class="col-md-6 pull-right">
              <!-- Start Big title -->
              <h1 class="big-title">
                Benefits and Rewards
              </h1>
              <!-- Accordion -->
              <div class="panel-group" id="accordion">
                <!-- Start Accordion 1 -->
                <div class="panel panel-default">
                  <!-- Toggle Heading -->
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapse-1">
                      Corporate Health and Wellness
                      </a>
                    </h4>
                  </div>
                  <!-- Toggle Content -->
                  <div id="collapse-1" class="panel-collapse collapse in">
                    <div class="panel-body">
                      <p>Don’t hesitate to contact us if you have any question or concern. We are here to help and are glad to resolve any of your issue. Please feel free to reach us anytime. We’ll get back to you as soon as possible.</p> 
                    </div>
                  </div>
                </div>
                <!-- End Accordion 1 -->

                <!-- Start Accordion 2 -->
                <div class="panel panel-default">
                  <!-- Toggle Heading -->
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapse-2" class="collapsed">
                      Our Company-Paid Benefits
                      </a>
                    </h4>
                  </div>
                  <!-- Toggle Content -->
                  <div id="collapse-2" class="panel-collapse collapse">
                    <div class="panel-body">
                      <p>Nam viverra scelerisque turpis id fermentum. Sed bibendum sit amet odio tempor venenatis. Quisque vel lectus sem. Sed convallis ligula sit amet. Nam viverra scelerisque turpis id fermentum.</p>  
                    </div>
                  </div>
                </div>
                <!-- End Accordion 2 -->

                <!-- Start Accordion 3 -->
                <div class="panel panel-bodyefault">
                  <!-- Toggle Heading -->
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapse-3" class="collapsed">
                      Voluntary Employee-Paid Benefits
                      </a>
                    </h4>
                  </div>
                  <!-- Toggle Content -->
                  <div id="collapse-3" class="panel-collapse collapse">
                    <div class="panel-body">
                      <p>I am text block. Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.</p>  
                    </div>
                  </div>
                </div>
                <!-- End Accordion 3 -->

                <!-- Start Accordion 4 -->
                <div class="panel panel-default">
                  <!-- Toggle Heading -->
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapse-4" class="collapsed">
                      Sed adipiscing ornare risus.
                      </a>
                    </h4>
                  </div>
                  <!-- Toggle Content -->
                  <div id="collapse-4" class="panel-collapse collapse">
                    <div class="panel-body">
                      <p>Donec ornare mattis suscipit. Praesent fermentum accumsan vulputate. Sed velit nulla, sagittis non erat id, dictum vestibulum ligula. Maecenas sed enim sem. Etiam scelerisque gravida purus nec interdum. Phasellus venenatis ligula in faucibus consequat. Aliquam dictum nulla eu varius porta. Maecenas congue.</p>
                    </div>
                  </div>
                </div>
                <!-- End Accordion 4 -->
              </div>
              <!-- End Accordion -->
              
              <!-- Divider -->
              
        </div>
              <!-- Open Positions Section Start -->
              <div class="col-md-6">              
              <div class="positions">              
                <div class="tabs-section">
                  <!-- Start Big title -->
                  <h1 class="big-title">
                    Open Positions
                  </h1>
                  <!-- Nav Tabs -->
                  <ul class="nav nav-tabs">
                    <li class="active tabs-1"><a href="#tab-1" data-toggle="tab"> Job Posting Title</a></li>
                    <li class="tabs-2"><a href="#tab-2" data-toggle="tab">Location</a></li>
                    <li class="tabs-3"><a href="#tab-3" data-toggle="tab">Department</a></li>
                    <li class="tabs-4"><a href="#tab-4" data-toggle="tab">Date</a></li>
                  </ul>
                  <!-- Tab panels -->
                  <div class="tab-content">
                    <!-- Tab Content 1 -->
                    <div class="tab-pane fade in active" id="tab-1">
                      <table class="table">                 
                        <tbody>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                    <!-- Tab Content 2 -->
                    <div class="tab-pane fade" id="tab-2">
                      <table class="table">     
                        <tbody>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                    <!-- Tab Content 3 -->
                    <div class="tab-pane fade" id="tab-3">
                      <table class="table">   
                        <tbody>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                    <!-- Tab Content 4 -->
                    <div class="tab-pane fade" id="tab-4">
                      <table class="table">     
                        <tbody>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                          <tr>
                            <td><a href="#">AJTSoftwareLabs</a></td>
                            <td>Bengaluru</td>
                            <td>Top Management</td>
                            <td>March 5, 2017</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <!-- End Tab Panels -->
                </div>
              </div>
              </div>
              <!-- Open Positions Section End -->
            </div>
          </div>
        </div>
      </section>
      <!-- End Content Section  -->
    
        <?php include ('footer.php')?>