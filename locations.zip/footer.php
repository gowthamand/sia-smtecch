<footer class="footer_color">
    <div class="container ">
        <div class="row footer-widgets ">
            <!-- Start Contact Widget -->
            <div class="textwidget">
                <center><b>Our Services<b></b></b>
                </center><b><b>

                    <center><a href="services-travel-portal-development.php">Travel Portal Development</a>&nbsp;|

                        &nbsp;<a href="services-airline-reservation-system.php">Airline Reservation System</a>&nbsp;|

                        &nbsp;<a href="services-hotel-booking-system.php">Hotel Booking System</a>&nbsp;|


                        &nbsp;<a href="services-gds-xml-api-integration.php">GDS XML API Integration </a>&nbsp;|

                        &nbsp;<a href="services-travel-technology-solutions.php">Travel Technology Solutions</a>&nbsp; </center>


                        <center><a href="services-e-commerce-portal.php">E Commerce Portal</a>&nbsp;&nbsp;&nbsp;|


                            &nbsp;&nbsp;&nbsp;<a href="services-job-board-development.php">Job Board Development</a>&nbsp;&nbsp;|


                            &nbsp;&nbsp;&nbsp;<a href="services-3rd-party-flight-integrations.php">3rd Party Flight Integrations</a>&nbsp;&nbsp;&nbsp;&nbsp;|


                            &nbsp;&nbsp;&nbsp;<a href="services-travel-portal-seo.php">Travel Portal SEO</a>&nbsp;&nbsp;&nbsp;&nbsp;|

                            &nbsp;&nbsp;&nbsp;<a href="travel-tools.php">Travel Tools</a>&nbsp;&nbsp;&nbsp;&nbsp;</center>

                            <hr>


                            <center>Our Client Base</center>

                            <center><a href="locations.php">India</a>&nbsp;|
                                <a href="locations.php">Africa</a>&nbsp;|
                                <a href="locations.php">Kenya</a>&nbsp;|
                                <a href="locations.php">Nigeria</a>&nbsp;|
                                <a href="locations.php">Tanzania</a>&nbsp;|
                                <a href="locations.php">South Africa</a>&nbsp;|
                                <a href="locations.php">Dubai</a>&nbsp;|
                                <a href="locations.php">Malaysia</a>&nbsp;|
                                <a href="locations.php">Singapore</a>&nbsp;|
                                <a href="locations.php">Hongkong</a>&nbsp;|
                                <a href="locations.php">France</a>&nbsp;|
                                <a href="locations.php">MiddleEast</a>&nbsp;|
                                <a href="locations.php">Thailand</a>&nbsp;|
                                <a href="locations.php">Europe</a>&nbsp;|
                                <a href="locations.php">Indonesia</a>&nbsp;<br><center>
                                    <hr>
                                    <center><b>Company<b></b></b>
                                    </center><b><b>

                                        <center><b><a href="about-us.php">About Us</a>&nbsp;|
                                            <a href="aboutus-technology.php">Technology</a>&nbsp;|
                                            <a href="portfolio.php"> portfolio</a>&nbsp;|
                                            <a href="privacy-policy.php">Privacy policy</a>&nbsp;|
                                            <a href="blog-and-press-release.php">Blog &amp; Press Release</a><b></b></b>
                                        </center><b><b>

                                            <hr>
                                            <center><b>Contact Details</b></center><b><b>

                                                Corporate Office: <a>#75/150 ft road,</a><a>Near DLF New Town,</a> <a>Akshaya Nagar,</a><a>Yelenahalli Bus Stop.</a><a> Bangalore-5600114.</a><a> Phone No : +91-9789639143</a><br>
                                                Nigeria Office : <a>A/2 Wushishi Road By,</a><a>Logos Street,</a><a> Kaduna,</a><a>Nigeria, </a><a>Phone No : +2348034534894</a><br>
                                                Kenya Office: <a>Dubai 2012,</a><a> Moi Drive,</a><a>Kenya,</a><a>Nairobi,</a><a>Phone No : +254722867700</a>
                                                <hr>
                                                <center><a href="contact-us.php" class="alignnone" style="margin: 0px; padding: 0px; display: inline-block; position: relative; overflow: hidden;"><img class="alignnone size-full wp-image-267" src="http://siasmtech.com/wp-content/uploads/2016/01/Quote_Button.png" alt="" width="205" height="44"><span class="image-overlay overlay-type-extern" style="display: none;"><span class="image-overlay-inside"></span></span></a></center>

                                            </b></b>
                                        </b>
                                    </b>
                                </b>
                            </b>
                        </center>
                    </center>
                </b>
            </b>
        </div>
    </div>
    <!-- .row -->
</div>
</footer>
<!-- End Footer Section -->
<div style="clear:both;"></div>
<!-- Start Copyright -->
<div class="copyright-section">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <p>© 2017 <a href="http://siasmtech.com">Sia-Smtech Pvt.Ltd.</a>All Rights Reserved
                </p>
            </div>
        </div>
        <!-- .row -->
    </div>
</div>
<!-- End Copyright -->
<div style="clear:both;"></div>

<!-- Go To Top Link -->
<a href="#" class="back-to-top">
    <i class="fa fa-angle-up"></i>
</a>

<!-- Start Loader -->
<div id="loader">
    <div class="square-spin">
        <div></div>
    </div>
</div>
<div style="clear:both;"></div>
<!-- Main JS  -->
<script type="text/javascript" src="assets/js/jquery-min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/js/owl.carousel.min.js"></script>
<script type="text/javascript" src="assets/js/modernizrr.js"></script>
<script type="text/javascript" src="assets/js/nivo-lightbox.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.mixitup.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.appear.js"></script>
<script type="text/javascript" src="assets/js/count-to.js"></script>
<script type="text/javascript" src="assets/js/jquery.parallax.js"></script>
<script type="text/javascript" src="assets/js/smooth-scroll.js"></script>
<script type="text/javascript" src="assets/js/jquery.slicknav.js"></script>
<script type="text/javascript" src="assets/js/main.js"></script>

<!-- Revelosition slider js -->
<script src="assets/js/jquery.themepunch.revolution.min.js"></script>
<script src="assets/js/jquery.themepunch.tools.min.js"></script>

<!-- Pop Up JS File -->
<script src="assets/js/custom.js"></script>

<div style="clear:both;"></div>
<!-- Modal -->
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">siasmtech</h4>
            </div>
            <div class="modal-body">
                <p>Some text in the modal.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>

    </div>
</div>
<div style="clear:both;"></div>
<!-- popup model ends -->
</body>
<!-- <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-62207710-1', 'http://siasmtech.com');
  ga('send', 'pageview');
  
</script> -->
</php>